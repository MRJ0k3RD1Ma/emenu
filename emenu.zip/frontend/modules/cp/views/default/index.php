<?php

$this->title = 'Dashboard';
$this->params['breadcrumbs'][] = $this->title;
?>