<?php
return [
    'adminEmail' => 'admin@example.com',
    'gender'=>[
        0=>'Ayol',
        1=>'Erkak',
    ],
    'user.status'=>[
        1=>'Aktiv',
        0=>'Deaktiv',
        -1=>'O`chirilgan'
    ],
    'default.region_id'=>33
];
